# REFLEXO INFINITO — projeto Android

Jogo casual de reflexo com interface neon, empacotado em Android WebView e integração inicial com anúncio recompensado do Google Mobile Ads.

## Estado desta entrega

- Código-fonte Android pronto para compilação em nuvem via GitHub Actions.
- O jogo está em `app/src/main/assets/index.html`.
- O botão de recompensa oferece uma vida extra quando o anúncio é concluído.
- O projeto usa IDs oficiais de TESTE do Google. Não gera receita enquanto permanecer com esses IDs.
- Este pacote ainda não é um APK compilado e não está pronto para publicação comercial.

## Como gerar o APK pelo celular (sem instalar Android Studio)

1. Crie uma conta gratuita em https://github.com/ e entre pelo navegador do celular.
2. Crie um repositório novo chamado `reflexo-infinito`.
3. Envie todos os arquivos e pastas deste projeto para a raiz do repositório (incluindo `.github`).
4. Abra a aba **Actions**, escolha **Build Android APK** e toque em **Run workflow**.
5. Quando terminar, abra a execução concluída e baixe o artefato `reflexo-infinito-debug-apk`. O APK de teste estará dentro do ZIP baixado.

O workflow compila com Android 16 / API 36, conforme a exigência atual para novos aplicativos na Play Store.

## Antes de monetizar e publicar

1. Criar conta AdMob, cadastrar o aplicativo e substituir o ID de aplicativo e a unidade de anúncio de teste em `AndroidManifest.xml` e `MainActivity.java`.
2. Implementar e configurar o consentimento de privacidade (Google UMP) conforme os países onde o app será distribuído.
3. Publicar uma política de privacidade acessível por URL e preencher a seção Segurança dos dados no Play Console.
4. Criar chave de assinatura de produção e configurar assinatura segura do Android App Bundle (AAB). O APK de debug deste workflow serve apenas para testes.
5. Criar conta Google Play Console (taxa de cadastro única, atualmente US$ 25), preencher ficha da loja, classificação indicativa e concluir os testes exigidos pela conta.

Nunca clique nos anúncios de teste para tentar gerar receita. Os anúncios de teste não pagam.
