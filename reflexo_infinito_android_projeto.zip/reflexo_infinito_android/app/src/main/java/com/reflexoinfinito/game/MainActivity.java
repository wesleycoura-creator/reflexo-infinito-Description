package com.reflexoinfinito.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private boolean adLoading = false;
    // Unidade de anúncio recompensado de TESTE oficial do Google. Trocar pela sua no lançamento.
    private static final String REWARDED_TEST_ID = "ca-app-pub-3940256099942544/5224354917";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        MobileAds.initialize(this, status -> runOnUiThread(this::loadRewarded));
    }

    private void loadRewarded() {
        if (adLoading || rewardedAd != null) return;
        adLoading = true;
        RewardedAd.load(this, REWARDED_TEST_ID, new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) {
                    rewardedAd = ad; adLoading = false;
                }
                @Override public void onAdFailedToLoad(LoadAdError error) {
                    rewardedAd = null; adLoading = false;
                }
            });
    }

    private class AdsBridge {
        @JavascriptInterface public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    notifyPage(false); loadRewarded(); return;
                }
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { loadRewarded(); }
                    @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                        notifyPage(false); loadRewarded();
                    }
                });
                ad.show(MainActivity.this, rewardItem -> {
                    notifyPage(true);
                    loadRewarded();
                });
            });
        }
    }

    private void notifyPage(boolean earned) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
            "window.onRewardedAdResult && window.onRewardedAdResult(" + earned + ")", null));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
